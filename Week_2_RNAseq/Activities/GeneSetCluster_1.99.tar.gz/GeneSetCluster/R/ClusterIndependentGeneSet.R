#' ClusterIndependentGeneSet
#'
#' Choose the most appropiate ordering method for the DataPathways.RR correlation matrix
#' @import seriation
#'
#'
#' @param Object a pathway object
#' @param iterations number of iterations to perform per method
#' @param use_method the method to use for ordering the correlation matrix
#'
#' @return PathwayObject
#'
#' @export
#'
setGeneric(name="ClusterIndependentGeneSet",
           def=function(Object, iterations = 3, use_method = NULL, all_methods = FALSE)
           {
             standardGeneric("ClusterIndependentGeneSet")
           }
)

#' ClusterIndependentGeneSet
#'
#' @param Object a pathway object
#' @param iterations number of iterations to perform per method
#' @param use_method the method to use for ordering the correlation matrix
#'
#' @return PathwayObject
#'
#' @export
#'

setMethod(f="ClusterIndependentGeneSet",
          signature = "PathwayObject",
          definition = function(Object, iterations = 3, use_method = NULL, all_methods = FALSE)
          {
            message("Performing the estimation for ALL the pathways...\n")
            mat_sym <- scaleCorMatrix(Object@Data.RR)
            # select the best ordering method for the correlation matrix
            ordergo <- optimalDist(mat_sym, all_methods = F, iterations = iterations, min_length = NULL, use_method = use_method)

            message("\nPerforming the estimation for UNIQUE pathways...\n")
            mat_symunique <- scaleCorMatrix(Object@DataPathways.RR)
            # select the best ordering method for the correlation matrix
            ordergounique <- optimalDist(mat_symunique, all_methods = F, iterations = iterations, min_length = NULL, use_method = use_method)

            Object@cIndependentMethod <- list(ordergo, ordergounique)

            return(Object)
          }
)
