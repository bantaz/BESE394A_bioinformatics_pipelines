#' PlotPathwayCluster
#'
#' Plots a correlation matrix showing the correlation between the pathways and a functional annotation of the group of pathways based on GO terms descriptions.
#' @import simplifyEnrichment
#' @import slam
#' @import GetoptLong
#' @import ComplexHeatmap
#' @import grid
#' @import RColorBrewer
#' @import colorRamp2
#' @import seriation
#'
#'
#' @param Object a pathway object
#' @param nPathway minimum number of pathways per group
#' @param doORA boolean perform ORA analysis
#' @param wordcloud boolean perform boolean to add wordcloud annotations of each cluster
#' @param iterations number of iterations to perform per method
#' @param use_method the method to use for ordering the correlation matrix
#'
#' @return plot
#'
#' @export
#'
setGeneric(name="PlotPathwayCluster",
           def=function(Object, nPathway = 6, doORA = TRUE, wordcloud = TRUE, uniquePathways = FALSE, iterations = 3, use_method = NULL, print_pathways = FALSE)
           {
             standardGeneric("PlotPathwayCluster")
           }
)

#' PlotPathwayCluster
#'
#' @param Object a pathway object
#' @param nPathway minimum number of pathways per group
#' @param doORA boolean to perform ORA analysis
#' @param wordcloud boolean to add wordcloud annotations of each cluster
#' @param iterations number of iterations to perform per method
#' @param use_method the method to use for ordering the correlation matrix
#' @param print_pathways print the pathways per group
#'
#' @return plot
#'
#' @examples

setMethod(f="PlotPathwayCluster",
          signature = "PathwayObject",
          definition = function(Object, nPathway = NULL, doORA = TRUE, wordcloud = TRUE, uniquePathways = FALSE, iterations = 3, use_method = NULL, print_pathways = FALSE)
          {

          if (is.null(Object@cIndependentMethod))
          {
            message("The cluster independent method is not defined. Please firstly run ClusterIndependentGeneSet in order to select the ordering method.")
            stop()
          }

          if (uniquePathways)
          {
            #scaling the matrix
            mat_sym <- scaleCorMatrix(Object@DataPathways.RR)
            mat_cor <- mat_sym[Object@cIndependentMethod[[2]][[1]], Object@cIndependentMethod[[2]][[1]]]
          } else {
            mat_sym <- scaleCorMatrix(Object@Data.RR)
            mat_cor <- mat_sym[Object@cIndependentMethod[[1]][[1]], Object@cIndependentMethod[[1]][[1]]]
          }

          res <- obtainDefCluster(mat_cor)
          if (is.null(nPathway)) {
            nPathway <- selectNpathways(mat_sym)
          }

          if (length(res[which(lapply(res, function(x) length(x))>=nPathway)]) == 0) {
            message(paste0("There is no groups with at least ", nPathway, " pathways. Using the minimum value, 3 pathways per group."))
            go_id_list <- res[which(lapply(res, function(x) length(x))>=3)]
          } else {
            go_id_list <- res[which(lapply(res, function(x) length(x))>=nPathway)]
          }

          #ora
          clusters <- length(go_id_list)
          clus <- vector()
          for (i in 1:clusters) {
            paths <- c(rep(i, length(go_id_list[[i]])))
            names(paths) <- go_id_list[[i]]
            clus <- c(clus, paths)
          }

          keywords_ora <- ORAperCluster(Object, doORA, clusters, clus)

          if (wordcloud)
          {
            if (checkGO(Object) == FALSE) {
              message("No GO terms have been detected in the pathways. The semantic enrichment word cloud will not be generated.")
              wordcloud = FALSE
            } else {
              #adapted from anno_word_cloud_from_GO function
              env_tdm_GO <- readRDS(system.file("extdata", "tdm_GO.rds", package = "simplifyEnrichment"))
              names(go_id_list) <- as.character(1:length(go_id_list))

              # keyword enrichment
              message(paste0("Performing keyword enrichment for "), length(go_id_list), " group(s) of pathways.")
              term <- lapply(go_id_list, function(x, min_stat=5) {
                df <- keywordEnrichment(x, env_tdm_GO)
                df <- df[df$p <= min_stat, , drop = FALSE]
                data.frame(df[, 1], -log10(df$p))
              })
            }
          }

          align_to <- go_id_list

          for (i in 1:length(align_to)){
            for (j in 1:length(align_to[[i]]))
              align_to[[i]][j] <- as.numeric(which(colnames(mat_cor) == align_to[[i]][j]))
          }

          align_to <- lapply(align_to, as.numeric)


          if (wordcloud == TRUE) {
            annot_label <- rowAnnotation(keywords = anno_word_cloud(align_to, term),
                                         annotation_name_align=T)
          } else {
            annot_label <- NULL
          }

          rowNumbers <- rowAnnotation(foo = anno_mark(at = unlist(lapply(align_to, function(x) round(mean(x)))),
                                            labels = rep(paste0("Group ", 1:length(align_to))),
                                            link_width = unit(0,"mm")))

          df_metadata <- obtainDFmetadata(Object@Data[[1]], mat_cor)

          annot_top <- HeatmapAnnotation(df=df_metadata, show_legend = F, annotation_name_gp = gpar(fontsize = 10))
          ht_opt$message <- FALSE

          color_fun <- colorRamp2(seq(min(mat_cor), max(mat_cor), length = 9), brewer.pal(9, "Reds"))

          plot <- Heatmap(mat_cor, cluster_rows = F, cluster_columns = F, show_row_names = F, show_column_names = F ,
                          name="Similarity", col=color_fun, top_annotation = annot_top, right_annotation = annot_label) + rowNumbers

          if (doORA == TRUE) {
            legend <- Legend(labels = rep(paste0(1:length(keywords_ora), "- ", keywords_ora)),
                             title = "\nORA", legend_gp = gpar(fill = 1:length(keywords_ora)),
                             nr=8,  title_position = "leftcenter-rot")

            mergedplot <- draw(plot, annotation_legend_list=legend, annotation_legend_side = "bottom")
          } else {
            mergedplot <- plot
          }

          return(mergedplot)
}
)

