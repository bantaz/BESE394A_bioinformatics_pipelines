setClassUnion("DForNULL", c("data.frame", "NULL", "matrix"))
setClassUnion("LISTorNULL", c("list", "NULL"))


#' PathwayObject
#'
#' @slot Data list.
#' @slot PData data.frame.
#' @slot metadata data.frame.
#' @slot plot list.
#' @slot Data.RR data.frame.
#' @slot DataPathways.RR data.frame.
#' @slot cIndependentMethod list.
#' @slot dfTissue data.frame.
#'
#' @return a PathwayObject
#' @export
#'
#'
#'

PathwayObject <- setClass(
  Class="PathwayObject",
  slots=list(
    Data="list",
    PData="data.frame",
    metadata="data.frame",
    plot="list",
    Data.RR="data.frame",
    DataPathways.RR="DForNULL",
    cIndependentMethod="LISTorNULL",
    dfTissue="DForNULL"),
  prototype=list(
    Data=NULL,
    PData=NULL,
    metadata = NULL,
    plot=NULL,
    Data.RR=NULL,
    DataPathways.RR=NULL,
    cIndependentMethod=NULL,
    dfTissue=NULL)
)
